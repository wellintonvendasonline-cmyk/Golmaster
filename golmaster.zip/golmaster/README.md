# ⚽ GolMaster — Canal de Previsões de Futebol com IA

App de previsões de futebol em tempo real, alimentado pelo Claude AI com busca na web.
Atualiza automaticamente a cada 2 minutos com placares ao vivo, resultados e previsões.

---

## 🚀 Como Colocar Online GRATUITAMENTE (Passo a Passo)

Você vai precisar de:
- Conta no **GitHub** (gratuita) → https://github.com
- Conta no **Render.com** (gratuita) → https://render.com
- Chave de API da **Anthropic** → https://console.anthropic.com

---

### PASSO 1 — Criar conta no GitHub e subir o projeto

1. Acesse https://github.com e crie uma conta (se não tiver)
2. Clique em **"New repository"** (botão verde)
3. Nome: `golmaster`
4. Deixe como **Public**
5. Clique em **"Create repository"**

Agora suba os arquivos. Você tem duas opções:

**Opção A — Pelo site (mais fácil, sem instalar nada):**
1. Na página do repositório criado, clique em **"uploading an existing file"**
2. Arraste a pasta `golmaster` inteira ou faça upload arquivo por arquivo
3. Clique em **"Commit changes"**

**Opção B — Pelo terminal (se tiver Git instalado):**
```bash
cd golmaster
git init
git add .
git commit -m "GolMaster inicial"
git remote add origin https://github.com/SEU_USUARIO/golmaster.git
git push -u origin main
```

---

### PASSO 2 — Obter sua Chave de API da Anthropic

1. Acesse https://console.anthropic.com
2. Faça login ou crie uma conta
3. Vá em **"API Keys"** no menu lateral
4. Clique em **"Create Key"**
5. Dê um nome (ex: "golmaster")
6. **Copie a chave** — ela começa com `sk-ant-...`
   ⚠️ Guarde bem! Ela só aparece uma vez.

---

### PASSO 3 — Criar conta no Render.com e fazer o Deploy

1. Acesse https://render.com e clique em **"Get Started for Free"**
2. Faça login com sua conta do **GitHub** (recomendado)
3. No dashboard, clique em **"New +"** → **"Web Service"**
4. Clique em **"Connect a repository"**
5. Selecione o repositório `golmaster`
6. Configure assim:

| Campo | Valor |
|-------|-------|
| **Name** | golmaster |
| **Region** | Oregon (US West) |
| **Branch** | main |
| **Root Directory** | server |
| **Runtime** | Node |
| **Build Command** | `npm install && cd ../client && npm install && npm run build` |
| **Start Command** | `node index.js` |
| **Plan** | **Free** |

7. Role para baixo até **"Environment Variables"**
8. Clique em **"Add Environment Variable"**
9. Adicione:
   - **Key:** `ANTHROPIC_API_KEY`
   - **Value:** `sk-ant-sua-chave-aqui` ← cole a chave copiada no Passo 2

10. Clique em **"Create Web Service"**

---

### PASSO 4 — Aguardar o Deploy (3-5 minutos)

O Render vai:
1. Baixar seu código do GitHub
2. Instalar as dependências (`npm install`)
3. Compilar o React (`npm run build`)
4. Iniciar o servidor Node.js

Quando aparecer **"Your service is live"** com um ✅ verde, seu app está online!

A URL será algo como: `https://golmaster.onrender.com`

---

### PASSO 5 — Acessar o App 🎉

Abra a URL gerada pelo Render no navegador.
O app vai carregar, buscar os jogos automaticamente via IA e exibir as previsões!

---

## ⚠️ Limitações do Plano Gratuito do Render

- O servidor **dorme após 15 minutos sem acesso** → na primeira visita do dia pode demorar 30-60 segundos para "acordar"
- **750 horas/mês** de uso gratuito (suficiente para uso normal)
- Para manter sempre ativo, você pode usar um serviço como https://uptimerobot.com para fazer ping a cada 10 minutos (também gratuito)

---

## 🔧 Estrutura do Projeto

```
golmaster/
├── server/              ← Backend Node.js (Express)
│   ├── index.js         ← Servidor principal + proxy para Anthropic API
│   ├── package.json
│   └── .env.example     ← Exemplo de variáveis de ambiente
│
├── client/              ← Frontend React (Vite)
│   ├── src/
│   │   ├── App.jsx      ← Componente principal do app
│   │   └── main.jsx     ← Entry point React
│   ├── index.html
│   ├── vite.config.js   ← Build aponta para server/dist
│   └── package.json
│
├── render.yaml          ← Configuração automática do Render
├── package.json
└── README.md
```

---

## 🔄 Como Funciona a Atualização em Tempo Real

```
Usuário abre o app
      ↓
Frontend React (cliente)
      ↓ POST /api/games a cada 2 minutos
Backend Node.js (servidor)
      ↓ chama API Anthropic com web_search habilitado
Claude AI pesquisa jogos do dia na internet
      ↓ retorna JSON estruturado com previsões
Backend repassa para o frontend
      ↓
App atualiza os cards com dados frescos
```

---

## 🛠️ Rodar Localmente (Desenvolvimento)

```bash
# 1. Clone o repositório
git clone https://github.com/SEU_USUARIO/golmaster.git
cd golmaster

# 2. Configure a chave no backend
cd server
cp .env.example .env
# Edite .env e adicione sua ANTHROPIC_API_KEY

# 3. Instale dependências do servidor
npm install

# 4. Em outro terminal, instale e rode o frontend
cd ../client
npm install
npm run dev

# 5. Em outro terminal, rode o servidor
cd ../server
node index.js

# Frontend: http://localhost:5173
# Backend:  http://localhost:3001
```

---

## 💰 Custos Estimados

| Serviço | Plano | Custo |
|---------|-------|-------|
| GitHub | Free | R$ 0 |
| Render.com | Free | R$ 0 |
| Anthropic API | Pay-per-use | ~R$ 0,05–0,15 por atualização |

A API da Anthropic cobra por uso. Cada atualização do app consome aproximadamente
**2.000–4.000 tokens** (busca web + resposta). Com o modelo claude-sonnet-4:
- ~$0.003–0.012 por atualização
- Se o app atualizar a cada 2 min por 8h/dia: ~$1–3/mês

A Anthropic oferece **$5 de crédito gratuito** para novos usuários — suficiente para
semanas de uso!

---

## 🆘 Problemas Comuns

**"ANTHROPIC_API_KEY não configurada"**
→ Vá no Dashboard do Render → seu serviço → Environment → adicione a variável

**Build falhou**
→ Verifique se o Root Directory está como `server` no Render

**App não carrega jogos**
→ Abra o console do navegador (F12) e veja o erro. Provavelmente a API key está errada.

**Servidor "dormindo"**
→ Normal no plano gratuito. Aguarde 30-60s na primeira visita ou configure o UptimeRobot.

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const fetch = require("node-fetch");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// ── Serve frontend estático (pasta dist gerada pelo Vite) ─────────────────
const DIST = path.join(__dirname, "dist");
app.use(express.static(DIST));

// ── Health check ──────────────────────────────────────────────────────────
app.get("/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// ── Proxy para Anthropic API ───────────────────────────────────────────────
app.post("/api/games", async (req, res) => {
  const apiKey = process.env.ANTHROPIC_API_KEY;

  if (!apiKey) {
    return res.status(500).json({
      error: "ANTHROPIC_API_KEY não configurada. Adicione a variável de ambiente no Render."
    });
  }

  const today = new Date().toLocaleDateString("pt-BR");

  const systemPrompt = `Você é o motor de dados do GolMaster, canal de previsões de futebol.

Sua tarefa: retornar APENAS um JSON válido (sem markdown, sem texto antes/depois) com os jogos de futebol de HOJE nas ligas:
- Premier League (Inglaterra)
- La Liga (Espanha)
- Bundesliga (Alemanha)
- Serie A (Itália)
- Ligue 1 (França)
- Brasileirão Série A (Brasil)

Use a busca web para obter dados reais e atualizados de hoje.

Formato obrigatório:
{
  "lastUpdated": "<ISO timestamp>",
  "accuracy": { "hits": 0, "misses": 0, "live": 0, "pending": 0 },
  "games": [
    {
      "id": "unico-id",
      "league": "premier|laliga|bundesliga|seriea|ligue1|brasileirao",
      "leagueName": "Nome completo",
      "leagueRound": "Rodada XX",
      "status": "live|scheduled|final",
      "kickoffBRT": "HH:MM",
      "score": "X — Y",
      "scoreNote": "2º tempo · 67'",
      "homeTeam": { "name": "Nome", "emoji": "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "form": ["v","v","e","d","v"] },
      "awayTeam": { "name": "Nome", "emoji": "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "form": ["v","e","d","v","v"] },
      "probHome": 45,
      "probDraw": 27,
      "probAway": 28,
      "probContext": "Explicação das probabilidades em 1 frase",
      "tags": ["live","mais","top"],
      "predictions": {
        "goals": {
          "value": "+2.5",
          "stars": 4,
          "sub": "Esperamos 3+ gols",
          "tag": "mais",
          "explain": "Explicação de 2-3 frases com dados reais"
        },
        "btts": {
          "value": "SIM",
          "stars": 3,
          "sub": "frase curta",
          "explain": "Explicação detalhada"
        },
        "winner": {
          "value": "Nome do time",
          "stars": 4,
          "sub": "XX% probabilidade",
          "explain": "Explicação detalhada",
          "correct": null,
          "resultNote": null
        }
      },
      "analysis": "Contexto do jogo em 2-3 frases",
      "isTopPick": false
    }
  ]
}

Regras:
- tags pode conter: "live", "mais", "menos", "top", "enc"
- Se status=final: score com placar real, "enc" nas tags, winner.correct (true/false), winner.resultNote
- goals.tag: "mais" se começa com "+", "menos" se começa com "-"
- isTopPick: true apenas para 2-3 jogos de maior confiança do dia
- Inclua TODOS os jogos de hoje das 6 ligas
- Use dados reais de hoje ${today}`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 8000,
        system: systemPrompt,
        tools: [{ type: "web_search_20250305", name: "web_search" }],
        messages: [{
          role: "user",
          content: `Busque os jogos de futebol de HOJE (${today}) nas 6 ligas indicadas. Use a busca web para obter dados reais com placares ao vivo, resultados e jogos agendados. Retorne APENAS o JSON válido, sem texto extra.`
        }]
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      console.error("Anthropic API error:", err);
      return res.status(response.status).json({ error: "Erro na API Anthropic", details: err });
    }

    const data = await response.json();

    // Monta texto de todos os blocos
    const fullText = (data.content || [])
      .map(b => (b.type === "text" ? b.text : ""))
      .filter(Boolean)
      .join("\n");

    // Extrai JSON
    const jsonMatch = fullText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.error("Resposta sem JSON:", fullText.slice(0, 500));
      return res.status(500).json({ error: "Resposta da IA sem JSON válido", raw: fullText.slice(0, 300) });
    }

    const clean = jsonMatch[0].replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    res.json(parsed);
  } catch (err) {
    console.error("Erro:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// ── Qualquer outra rota → serve o React app ───────────────────────────────
app.get("*", (req, res) => {
  res.sendFile(path.join(DIST, "index.html"));
});

app.listen(PORT, () => {
  console.log(`✅ GolMaster Server rodando na porta ${PORT}`);
  console.log(`🔑 API Key: ${process.env.ANTHROPIC_API_KEY ? "✅ configurada" : "❌ NÃO configurada"}`);
});

import { useState, useEffect, useCallback, useRef } from "react";

// ─── CONFIG ────────────────────────────────────────────────────────────────
const API_URL = import.meta.env.VITE_API_URL || "/api/games";
const REFRESH_INTERVAL = 120; // segundos

// ─── CONSTANTES ────────────────────────────────────────────────────────────
const LEAGUES = [
  { id: "all",         label: "Todas",       flag: "🎯" },
  { id: "premier",     label: "Premier",     flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿" },
  { id: "laliga",      label: "La Liga",     flag: "🇪🇸" },
  { id: "bundesliga",  label: "Bundesliga",  flag: "🇩🇪" },
  { id: "seriea",      label: "Série A",     flag: "🇮🇹" },
  { id: "ligue1",      label: "Ligue 1",     flag: "🇫🇷" },
  { id: "brasileirao", label: "Brasileirão", flag: "🇧🇷" },
];

const FILTERS = [
  { id: "all",   label: "Todos",       icon: "🎯" },
  { id: "live",  label: "Ao Vivo",     icon: "🔴" },
  { id: "mais",  label: "Mais Gols",   icon: "🔥" },
  { id: "menos", label: "Menos Gols",  icon: "🔒" },
  { id: "top",   label: "Top Picks",   icon: "⭐" },
  { id: "enc",   label: "Encerrados",  icon: "✅" },
];

const GUIDE_TABS = [
  { id: "como",      label: "📖 Como Ler" },
  { id: "glossario", label: "📚 Glossário" },
  { id: "metodo",    label: "🔬 Metodologia" },
];

// ─── HELPERS ───────────────────────────────────────────────────────────────
const stars = (n = 0) => "★".repeat(Math.min(n, 5)) + "☆".repeat(Math.max(0, 5 - n));
const fmtDate = () => {
  const d = new Date();
  const days = ["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
  const months = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];
  return `${days[d.getDay()]}, ${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
};
const leagueDot = (l) => ({
  premier: "#3fc1f0", laliga: "#e74c3c", bundesliga: "#d4a017",
  seriea: "#3498db", ligue1: "#9b59b6", brasileirao: "#009c3b"
})[l] || "#536a82";

// ─── FETCH ─────────────────────────────────────────────────────────────────
async function fetchGames() {
  const res = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ date: new Date().toLocaleDateString("pt-BR") }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: `HTTP ${res.status}` }));
    throw new Error(err.error || `Erro ${res.status}`);
  }
  return res.json();
}

// ─── SUB-COMPONENTES ───────────────────────────────────────────────────────
function FormDots({ form = [] }) {
  return (
    <div style={{ display: "flex", gap: 3 }}>
      {form.map((r, i) => (
        <div key={i} title={r === "v" ? "Vitória" : r === "e" ? "Empate" : "Derrota"} style={{
          width: 8, height: 8, borderRadius: "50%",
          background: r === "v" ? "#00b85e" : r === "e" ? "#ffcc00" : "#ff3355",
        }} />
      ))}
    </div>
  );
}

function PredCell({ pred = {}, type }) {
  const [hov, setHov] = useState(false);
  const isOk  = pred.correct === true;
  const isErr = pred.correct === false;

  const valColor = isOk ? "#00e67a" : isErr ? "#ff3355"
    : pred.stars >= 4 ? "#00e67a" : pred.stars >= 3 ? "#ffcc00" : "#8aa0b8";

  const tagStyle = pred.tag === "mais"
    ? { bg: "rgba(255,124,42,.2)", c: "#ff7c2a", lbl: "+GOLS" }
    : pred.tag === "menos"
    ? { bg: "rgba(30,144,255,.2)", c: "#1e90ff", lbl: "-GOLS" }
    : isOk  ? { bg: "rgba(0,230,122,.15)",  c: "#00e67a", lbl: "ACERTOU" }
    : isErr ? { bg: "rgba(255,51,85,.15)",   c: "#ff3355", lbl: "ERROU" }
    : null;

  const icon = isOk ? "✅" : isErr ? "❌"
    : type === "goals" ? (pred.tag === "mais" ? "🔥" : "🔒")
    : type === "btts"  ? "⚽" : "🏆";

  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        padding: "12px 12px 10px", borderRight: "1px solid #1c2d3e",
        position: "relative", cursor: "default", flex: 1,
        background: hov ? "rgba(255,255,255,.02)" : "transparent", transition: "background .2s",
      }}
    >
      {hov && pred.explain && (
        <div style={{
          position: "absolute", bottom: "calc(100% + 8px)", left: 0, right: 0, zIndex: 300,
          background: "#121e2a", border: "1px solid #243649", borderRadius: 10,
          padding: 12, fontSize: 12, color: "#8aa0b8", lineHeight: 1.6,
          boxShadow: "0 8px 32px rgba(0,0,0,.8)", pointerEvents: "none",
        }}>
          {pred.explain}
          <div style={{
            position: "absolute", top: "100%", left: "50%", transform: "translateX(-50%)",
            borderWidth: 6, borderStyle: "solid",
            borderColor: "#243649 transparent transparent transparent",
          }} />
        </div>
      )}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 7 }}>
        <span style={{ fontSize: 17 }}>{icon}</span>
        {tagStyle && (
          <span style={{
            fontSize: 9, fontWeight: 700, letterSpacing: 1, padding: "2px 6px",
            borderRadius: 4, textTransform: "uppercase",
            background: tagStyle.bg, color: tagStyle.c,
          }}>{tagStyle.lbl}</span>
        )}
      </div>
      <div style={{ fontSize: 10, color: "#536a82", letterSpacing: "1.5px", textTransform: "uppercase", marginBottom: 4, fontWeight: 600 }}>
        {type === "goals" ? "Total de Gols" : type === "btts" ? "Ambas Marcam" : "Vencedor"}
      </div>
      <div style={{
        fontFamily: "'Bebas Neue', cursive", fontSize: 22, lineHeight: 1, marginBottom: 4,
        color: valColor, textDecoration: isErr ? "line-through" : "none", opacity: isErr ? .6 : 1,
      }}>{pred.value || "—"}</div>
      <div style={{ fontSize: 10, color: "#ffcc00", letterSpacing: 1, marginBottom: 3 }}>{stars(pred.stars)}</div>
      <div style={{ fontSize: 11, color: "#536a82" }}>{pred.sub || ""}</div>
    </div>
  );
}

function GameCard({ game, delay = 0 }) {
  const [infoOpen, setInfoOpen] = useState(false);
  const isLive  = game.status === "live";
  const isFinal = game.status === "final";
  const isTop   = game.isTopPick;

  const ribbonBg = isLive ? "#ff3355"
    : isTop ? "linear-gradient(90deg,#ffcc00,#ff7c2a)"
    : isFinal ? "#1c2d3e"
    : game.tags?.includes("mais") ? "linear-gradient(90deg,#ff7c2a,#ffaa00)"
    : game.tags?.includes("menos") ? "linear-gradient(90deg,#1e90ff,#00cfff)"
    : "#1c2d3e";

  const borderColor = isLive ? "rgba(255,51,85,.4)"
    : isTop ? "rgba(255,204,0,.25)"
    : "#1c2d3e";

  return (
    <div style={{
      background: "#0e1620", border: `1px solid ${borderColor}`, borderRadius: 18,
      overflow: "hidden", animation: `rise .4s ease ${delay}s both`,
      transition: "transform .25s, border-color .25s, box-shadow .25s",
    }}
      onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 8px 40px rgba(0,0,0,.5)"; }}
      onMouseLeave={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "none"; }}
    >
      <div style={{ height: 3, background: ribbonBg }} />

      <div style={{ padding: "18px 20px 0" }}>
        {/* Meta */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14, flexWrap: "wrap", gap: 8 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 11, color: "#536a82", fontWeight: 700, letterSpacing: "1.5px", textTransform: "uppercase" }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: leagueDot(game.league) }} />
            {game.leagueName} · {game.leagueRound}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 7, flexWrap: "wrap" }}>
            {isLive && (
              <span style={{ display: "flex", alignItems: "center", gap: 5, background: "rgba(255,51,85,.15)", border: "1px solid rgba(255,51,85,.4)", padding: "3px 9px", borderRadius: 10, fontSize: 10, fontWeight: 700, color: "#ff3355", letterSpacing: "1.5px" }}>
                <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#ff3355", animation: "blink 1s infinite", display: "inline-block" }} />LIVE
              </span>
            )}
            {isTop && <span style={{ background: "#ffcc00", color: "#000", fontSize: 10, fontWeight: 900, letterSpacing: 2, padding: "3px 9px", borderRadius: 6 }}>⭐ TOP</span>}
            {!isTop && game.tags?.includes("mais")  && <span style={{ background: "rgba(255,124,42,.18)", border: "1px solid rgba(255,124,42,.35)", color: "#ff7c2a",  fontSize: 10, fontWeight: 700, padding: "3px 9px", borderRadius: 6 }}>🔥 +GOLS</span>}
            {!isTop && game.tags?.includes("menos") && <span style={{ background: "rgba(30,144,255,.15)",  border: "1px solid rgba(30,144,255,.35)", color: "#1e90ff", fontSize: 10, fontWeight: 700, padding: "3px 9px", borderRadius: 6 }}>🔒 -GOLS</span>}
            {isFinal && <span style={{ background: "rgba(28,45,62,.8)", border: "1px solid #1c2d3e", color: "#536a82", fontSize: 10, fontWeight: 700, padding: "3px 9px", borderRadius: 6 }}>✅ ENCERRADO</span>}
          </div>
          <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 13, color: "#ffcc00", letterSpacing: 1 }}>
            {game.kickoffBRT} BRT
          </span>
        </div>

        {/* Times */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center", gap: 14, marginBottom: 18 }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
            <span style={{ fontSize: 28, lineHeight: 1 }}>{game.homeTeam?.emoji}</span>
            <span style={{ fontSize: 15, fontWeight: 700, color: "#ddeeff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 140 }}>{game.homeTeam?.name}</span>
            <span style={{ fontSize: 10, color: "#536a82", letterSpacing: 1 }}>Forma</span>
            <FormDots form={game.homeTeam?.form} />
          </div>

          <div style={{ textAlign: "center", flexShrink: 0 }}>
            {game.score && game.score !== "null" ? (
              <>
                <span style={{
                  fontFamily: "'Bebas Neue', cursive", fontSize: 32, letterSpacing: 4, display: "block", lineHeight: 1,
                  color: isLive ? "#ff3355" : "#00e67a",
                  textShadow: isLive ? "0 0 16px rgba(255,51,85,.5)" : "none",
                }}>{game.score}</span>
                <span style={{ fontSize: 9, color: isLive ? "#ff3355" : "#536a82", letterSpacing: 2, textTransform: "uppercase", display: "block", marginTop: 2, animation: isLive ? "blink 1.2s infinite" : "none" }}>
                  {game.scoreNote || (isLive ? "em curso" : "")}
                </span>
              </>
            ) : (
              <span style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 18, color: "#243649", letterSpacing: 3 }}>VS</span>
            )}
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 5, alignItems: "flex-end" }}>
            <span style={{ fontSize: 28, lineHeight: 1 }}>{game.awayTeam?.emoji}</span>
            <span style={{ fontSize: 15, fontWeight: 700, color: "#ddeeff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 140, textAlign: "right" }}>{game.awayTeam?.name}</span>
            <span style={{ fontSize: 10, color: "#536a82", letterSpacing: 1 }}>Forma</span>
            <FormDots form={game.awayTeam?.form} />
          </div>
        </div>

        {/* Barra de probabilidade */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
            <span style={{ fontSize: 10, color: "#536a82", letterSpacing: "1.5px", textTransform: "uppercase", fontWeight: 600 }}>📊 Probabilidade de Resultado</span>
            <button onClick={() => setInfoOpen(v => !v)} style={{
              background: "transparent", border: "none", cursor: "pointer",
              color: infoOpen ? "#00e67a" : "#536a82", fontSize: 14, padding: "2px 6px", borderRadius: 4, transition: "color .2s",
            }}>ℹ️</button>
          </div>
          {infoOpen && (
            <div style={{ background: "#121e2a", border: "1px solid #243649", borderRadius: 10, padding: "10px 14px", marginBottom: 10, fontSize: 12, color: "#8aa0b8", lineHeight: 1.6 }}>
              {game.probContext || "Probabilidades baseadas em dados históricos e forma recente."}
            </div>
          )}
          <div style={{ display: "flex", height: 30, borderRadius: 8, overflow: "hidden", gap: 3 }}>
            <div style={{ flex: game.probHome, display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg,#003d15,#00b85e)", color: "#000", fontSize: 11, fontWeight: 700, minWidth: 40, borderRadius: "8px 0 0 8px" }}>
              {game.homeTeam?.name?.split(" ")[0]} {game.probHome}%
            </div>
            <div style={{ flex: game.probDraw, display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg,#3a2d00,#ccaa00)", color: "#000", fontSize: 11, fontWeight: 700, minWidth: 30 }}>
              E {game.probDraw}%
            </div>
            <div style={{ flex: game.probAway, display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg,#0c1e40,#1e90ff)", color: "#fff", fontSize: 11, fontWeight: 700, minWidth: 40, borderRadius: "0 8px 8px 0" }}>
              {game.awayTeam?.name?.split(" ")[0]} {game.probAway}%
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "#536a82", marginTop: 5, padding: "0 2px" }}>
            <span>Vitória {game.homeTeam?.name?.split(" ")[0]}</span>
            <span>Empate</span>
            <span>Vitória {game.awayTeam?.name?.split(" ")[0]}</span>
          </div>
        </div>
      </div>

      {/* Previsões */}
      <div style={{ display: "flex", borderTop: "1px solid #1c2d3e" }}>
        <PredCell pred={game.predictions?.goals}  type="goals" />
        <PredCell pred={game.predictions?.btts}   type="btts" />
        <div style={{ flex: 1 }}><PredCell pred={game.predictions?.winner} type="winner" /></div>
      </div>

      {/* Análise */}
      {game.analysis && (
        <div style={{ padding: "10px 18px", background: "rgba(11,17,24,.7)", borderTop: "1px solid #1c2d3e" }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: "#536a82", letterSpacing: 2, textTransform: "uppercase", marginBottom: 4 }}>
            🔍 Contexto do Jogo
          </div>
          <div style={{ fontSize: 12, color: "#8aa0b8", lineHeight: 1.6 }}>{game.analysis}</div>
        </div>
      )}
    </div>
  );
}

function GuidePanel({ tab }) {
  const items = {
    como: [
      { icon: "📊", title: "Barra de Probabilidade", body: "Mostra a chance (%) de cada resultado. Quanto maior o segmento, maior a probabilidade. Verde = casa, Amarelo = empate, Azul = fora.", ex: "Casa 55% | Empate 22% | Fora 23%" },
      { icon: "🔥", title: "+2.5 Gols (Over)", body: "+2.5 = esperamos MAIS de 2 gols no total, ou seja, pelo menos 3 gols. +3.5 = pelo menos 4 gols no jogo.", ex: "+2.5 → precisa de 3+ gols\n+3.5 → precisa de 4+ gols" },
      { icon: "🔒", title: "-2.5 Gols (Under)", body: "-2.5 = esperamos MENOS de 3 gols, ou seja, 0, 1 ou 2 gols no total do jogo.", ex: "-1.5 → 0 ou 1 gol\n-2.5 → 0, 1 ou 2 gols" },
      { icon: "⚽", title: "Ambas Marcam (BTTS)", body: "SIM = os dois times marcam pelo menos 1 gol. NÃO = pelo menos um time não marca nada.", ex: "SIM: 1x1, 2x1, 3x2 ✅\nNÃO: 1x0, 0x0, 2x0 ✅" },
      { icon: "⭐", title: "Estrelas de Confiança", body: "De ★☆☆☆☆ a ★★★★★ — indica o quão confiante o sistema está na previsão, com base em consistência histórica.", ex: "★★★★★ = Alta confiança\n★★☆☆☆ = Baixa confiança" },
      { icon: "💡", title: "Tooltips Explicativos", body: "Passe o cursor (ou toque) em qualquer previsão para ver a explicação detalhada com dados reais que embasam a análise.", ex: "↑ Experimente nos cards abaixo!" },
    ],
    glossario: [
      ["Over/Under (+/−)", "Previsão sobre o total de gols na partida"],
      ["BTTS", "Both Teams To Score — Ambos os times marcam"],
      ["xG (Expected Goals)", "Gols esperados com base na qualidade das chances criadas"],
      ["Clean Sheet", "Jogo sem sofrer nenhum gol"],
      ["Top Pick", "Previsão de alta confiança, destaque do dia"],
      ["HT/FT", "Half Time / Full Time — resultado no intervalo e no final"],
      ["Win Probability", "% de chance de vitória calculado por modelo estatístico"],
      ["Der Klassiker", "Clássico Borussia Dortmund × Bayern Munich"],
      ["El Clásico", "Clássico Real Madrid × Barcelona"],
      ["Grenal", "Clássico gaúcho: Internacional × Grêmio"],
      ["Choque-Rei", "Clássico paulista: Palmeiras × São Paulo"],
      ["Forma Recente", "Resultados dos últimos 5 jogos: V=Vitória E=Empate D=Derrota"],
      ["BRT", "Horário de Brasília (UTC-3)"],
    ],
    metodo: [
      { icon: "🤖", title: "IA com Busca Web Real", body: "O GolMaster usa o Claude da Anthropic com capacidade de busca na web, consultando fontes ao vivo antes de gerar as previsões do dia." },
      { icon: "📐", title: "Modelo de Gols (Over/Under)", body: "Baseado na média de gols das últimas partidas de cada time (casa e fora separados), ponderadas pela qualidade defensiva do adversário." },
      { icon: "🔁", title: "Peso da Forma Recente", body: "Os últimos 5 resultados têm peso maior que partidas anteriores. Uma sequência de vitórias aumenta a confiança na previsão." },
      { icon: "⚙️", title: "Atualização Automática", body: "O app busca dados frescos a cada 2 minutos automaticamente, usando a API do Claude para processar dados reais da web." },
      { icon: "🎯", title: "Estrelas de Confiança", body: "Calculadas com base em consistência histórica do padrão. 9/10 times marcando em casa = confiança máxima no BTTS SIM." },
      { icon: "🌐", title: "6 Ligas Monitoradas", body: "Premier League, La Liga, Bundesliga, Serie A, Ligue 1 e Brasileirão — todos os jogos de hoje, atualizados em tempo real." },
    ],
  };

  if (tab === "como") return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px,1fr))", gap: 12 }}>
      {items.como.map(({ icon, title, body, ex }) => (
        <div key={title} style={{ background: "#0e1620", border: "1px solid #1c2d3e", borderRadius: 12, padding: 16 }}>
          <div style={{ fontSize: 22, marginBottom: 8 }}>{icon}</div>
          <div style={{ fontWeight: 600, color: "#ddeeff", fontSize: 13, marginBottom: 6 }}>{title}</div>
          <div style={{ fontSize: 12, color: "#8aa0b8", lineHeight: 1.6, marginBottom: 10 }}>{body}</div>
          <div style={{ padding: "7px 10px", borderRadius: 6, background: "rgba(0,230,122,.07)", borderLeft: "3px solid #00e67a", fontFamily: "'DM Mono', monospace", fontSize: 11, color: "#00e67a", whiteSpace: "pre-wrap" }}>{ex}</div>
        </div>
      ))}
    </div>
  );

  if (tab === "glossario") return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
      {items.glossario.map(([k, v]) => (
        <div key={k} style={{ background: "#0e1620", border: "1px solid #1c2d3e", borderRadius: 8, padding: "7px 12px", fontSize: 12, color: "#8aa0b8" }}>
          <strong style={{ color: "#ddeeff" }}>{k}</strong> — {v}
        </div>
      ))}
    </div>
  );

  if (tab === "metodo") return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px,1fr))", gap: 12 }}>
      {items.metodo.map(({ icon, title, body }) => (
        <div key={title} style={{ background: "#0e1620", border: "1px solid #1c2d3e", borderRadius: 12, padding: 16 }}>
          <div style={{ fontSize: 22, marginBottom: 8 }}>{icon}</div>
          <div style={{ fontWeight: 600, color: "#ddeeff", fontSize: 13, marginBottom: 6 }}>{title}</div>
          <div style={{ fontSize: 12, color: "#8aa0b8", lineHeight: 1.6 }}>{body}</div>
        </div>
      ))}
    </div>
  );
  return null;
}

// ─── APP PRINCIPAL ─────────────────────────────────────────────────────────
export default function App() {
  const [data,           setData]     = useState(null);
  const [loading,        setLoading]  = useState(true);
  const [error,          setError]    = useState(null);
  const [lastFetch,      setLastFetch] = useState(null);
  const [activeFilter,   setAF]       = useState("all");
  const [activeLeague,   setAL]       = useState("all");
  const [guideTab,       setGuide]    = useState(null);
  const [dismissed,      setDismiss]  = useState(false);
  const [countdown,      setCountdown] = useState(REFRESH_INTERVAL);
  const timerRef    = useRef(null);
  const countdownRef = useRef(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetchGames();
      setData(result);
      setLastFetch(new Date());
      setCountdown(REFRESH_INTERVAL);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    timerRef.current     = setInterval(load, REFRESH_INTERVAL * 1000);
    countdownRef.current = setInterval(() => setCountdown(c => c <= 1 ? REFRESH_INTERVAL : c - 1), 1000);
    return () => {
      clearInterval(timerRef.current);
      clearInterval(countdownRef.current);
    };
  }, [load]);

  const games    = data?.games || [];
  const filtered = games.filter(g => {
    const tagOk    = activeFilter === "all" || g.tags?.includes(activeFilter);
    const leagueOk = activeLeague === "all" || g.league === activeLeague;
    return tagOk && leagueOk;
  });

  const acc    = data?.accuracy || {};
  const accPct = (acc.hits || 0) + (acc.misses || 0) > 0
    ? Math.round(((acc.hits || 0) / ((acc.hits || 0) + (acc.misses || 0))) * 100) : 0;

  return (
    <div style={{ minHeight: "100vh", background: "#060a0e", color: "#ddeeff", fontFamily: "'DM Sans', sans-serif", overflowX: "hidden" }}>
      <style>{`
        *{box-sizing:border-box;margin:0;padding:0}
        @keyframes rise{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:.15}}
        @keyframes orb{0%,100%{box-shadow:0 0 28px rgba(0,230,122,.45)}50%{box-shadow:0 0 50px rgba(0,230,122,.8)}}
        @keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}
        ::-webkit-scrollbar{width:5px;height:5px}
        ::-webkit-scrollbar-track{background:#0b1118}
        ::-webkit-scrollbar-thumb{background:#1c2d3e;border-radius:3px}
        body{background:#060a0e}
      `}</style>

      {/* Background FX */}
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
        background: "radial-gradient(ellipse 80% 50% at 20% -10%,rgba(0,230,122,.06) 0%,transparent 60%),radial-gradient(ellipse 60% 40% at 85% 110%,rgba(30,144,255,.05) 0%,transparent 60%)" }} />
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
        backgroundImage: "linear-gradient(rgba(0,230,122,.018) 1px,transparent 1px),linear-gradient(90deg,rgba(0,230,122,.018) 1px,transparent 1px)",
        backgroundSize: "52px 52px" }} />

      {/* ── HEADER ── */}
      <header style={{ position: "relative", zIndex: 100, background: "rgba(6,10,14,.96)", borderBottom: "1px solid #243649", backdropFilter: "blur(20px)", padding: "0 20px", boxShadow: "0 1px 40px rgba(0,230,122,.1)" }}>
        <div style={{ maxWidth: 1120, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", height: 70, gap: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 46, height: 46, borderRadius: 14, background: "linear-gradient(135deg,#00b85e,#00e67a)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, animation: "orb 3s ease-in-out infinite", flexShrink: 0 }}>⚽</div>
            <div>
              <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 28, letterSpacing: 3, color: "#fff", lineHeight: 1 }}>GOL<span style={{ color: "#00e67a" }}>MASTER</span></div>
              <div style={{ fontSize: 10, color: "#536a82", letterSpacing: 3, textTransform: "uppercase" }}>Canal de Previsões · IA em Tempo Real</div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
            <span style={{ padding: "5px 12px", borderRadius: 20, background: "rgba(28,45,62,.6)", border: "1px solid #1c2d3e", fontSize: 11, color: "#536a82", fontFamily: "'DM Mono', monospace" }}>↻ {countdown}s</span>
            <span style={{ padding: "5px 12px", borderRadius: 20, background: "rgba(28,45,62,.6)", border: "1px solid #1c2d3e", fontSize: 11, color: "#8aa0b8", letterSpacing: 1 }}>{fmtDate()}</span>
            <span style={{ display: "flex", alignItems: "center", gap: 6, padding: "5px 12px", borderRadius: 20, background: "rgba(255,51,85,.12)", border: "1px solid rgba(255,51,85,.4)", fontSize: 11, color: "#ff3355", fontWeight: 700, letterSpacing: "1.5px" }}>
              <span style={{ width: 7, height: 7, borderRadius: "50%", background: "#ff3355", animation: "blink 1.1s infinite", display: "inline-block" }} />AO VIVO
            </span>
          </div>
        </div>
      </header>

      {/* ── SUBNAV ── */}
      <nav style={{ position: "relative", zIndex: 99, background: "rgba(11,17,24,.95)", borderBottom: "1px solid #1c2d3e", padding: "0 20px", overflowX: "auto" }}>
        <div style={{ maxWidth: 1120, margin: "0 auto", display: "flex", gap: 4, padding: "8px 0", alignItems: "center" }}>
          {[{ id: null, label: "🏠 Jogos" }, ...GUIDE_TABS.map(t => ({ id: t.id, label: t.label }))].map(({ id, label }) => (
            <button key={label} onClick={() => setGuide(guideTab === id ? null : id)} style={{
              background: guideTab === id ? "rgba(0,230,122,.1)" : "transparent",
              border: "none", cursor: "pointer",
              color: guideTab === id ? "#00e67a" : "#536a82",
              fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 600,
              padding: "6px 14px", borderRadius: 20, transition: "all .2s", whiteSpace: "nowrap",
            }}>{label}</button>
          ))}
          <button onClick={load} disabled={loading} style={{
            marginLeft: "auto", background: loading ? "rgba(28,45,62,.4)" : "rgba(0,230,122,.1)",
            border: `1px solid ${loading ? "#1c2d3e" : "rgba(0,230,122,.3)"}`,
            cursor: loading ? "not-allowed" : "pointer", color: loading ? "#536a82" : "#00e67a",
            fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 600,
            padding: "6px 14px", borderRadius: 20, transition: "all .2s",
            display: "flex", alignItems: "center", gap: 6, flexShrink: 0,
          }}>
            <span style={{ display: "inline-block", animation: loading ? "spin .8s linear infinite" : "none" }}>↻</span>
            {loading ? "Buscando..." : "Atualizar"}
          </button>
        </div>
      </nav>

      {/* ── GUIA ── */}
      {guideTab && (
        <div style={{ position: "relative", zIndex: 5, maxWidth: 1120, margin: "18px auto 0", padding: "0 20px" }}>
          <div style={{ background: "#121e2a", border: "1px solid #243649", borderRadius: 18, padding: 24 }}>
            <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 20, letterSpacing: 2, color: "#00e67a", marginBottom: 18 }}>
              {GUIDE_TABS.find(t => t.id === guideTab)?.label}
            </div>
            <GuidePanel tab={guideTab} />
          </div>
        </div>
      )}

      {/* ── PLACAR ACERTOS ── */}
      {data && (
        <div style={{ position: "relative", zIndex: 5, maxWidth: 1120, margin: "20px auto 0", padding: "0 20px" }}>
          <div style={{ background: "linear-gradient(135deg,#121e2a,#0e1620)", border: "1px solid #243649", borderRadius: 18, padding: "18px 22px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 14 }}>
            <div>
              <div style={{ fontSize: 10, color: "#536a82", letterSpacing: 3, textTransform: "uppercase", marginBottom: 4 }}>⚡ Acertos de Hoje</div>
              <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
                <span style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 48, lineHeight: 1, color: "#00e67a" }}>{accPct}%</span>
                <span style={{ fontSize: 12, color: "#8aa0b8", lineHeight: 1.5 }}>precisão<br/>encerrados</span>
              </div>
            </div>
            <div style={{ display: "flex", gap: 18, flexWrap: "wrap" }}>
              {[
                { v: acc.hits ?? 0,    l: "Acertos",   c: "#00e67a" },
                { v: acc.misses ?? 0,  l: "Erros",     c: "#ff3355" },
                { v: acc.live ?? 0,    l: "Ao Vivo",   c: "#ffcc00" },
                { v: acc.pending ?? 0, l: "Aguardando",c: "#1e90ff" },
                { v: games.length,     l: "Jogos",     c: "#ddeeff" },
              ].map(({ v, l, c }) => (
                <div key={l} style={{ textAlign: "center" }}>
                  <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 26, lineHeight: 1, color: c, marginBottom: 2 }}>{v}</div>
                  <div style={{ fontSize: 10, color: "#536a82", letterSpacing: "1.5px", textTransform: "uppercase" }}>{l}</div>
                </div>
              ))}
            </div>
            <div style={{ flex: 1, minWidth: 150 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#8aa0b8", marginBottom: 6 }}>
                <span>Taxa de acerto</span>
                <span style={{ color: "#00e67a", fontWeight: 600 }}>{accPct}%</span>
              </div>
              <div style={{ height: 8, background: "rgba(28,45,62,.8)", borderRadius: 4, overflow: "hidden" }}>
                <div style={{ height: "100%", borderRadius: 4, background: "linear-gradient(90deg,#00b85e,#00e67a)", width: `${accPct}%`, transition: "width .8s ease" }} />
              </div>
              {lastFetch && (
                <div style={{ fontSize: 10, color: "#536a82", marginTop: 5 }}>
                  Atualizado: {lastFetch.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── ONBOARD ── */}
      {!dismissed && !loading && data && (
        <div style={{ position: "relative", zIndex: 5, maxWidth: 1120, margin: "16px auto 0", padding: "0 20px" }}>
          <div style={{ background: "linear-gradient(135deg,rgba(0,230,122,.07),rgba(30,144,255,.05))", border: "1px solid rgba(0,230,122,.15)", borderRadius: 16, padding: "18px 22px", display: "flex", alignItems: "flex-start", gap: 16, flexWrap: "wrap" }}>
            <span style={{ fontSize: 28, flexShrink: 0 }}>💡</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 17, letterSpacing: 2, color: "#00e67a", marginBottom: 5 }}>Como usar o GolMaster</div>
              <div style={{ fontSize: 12, color: "#8aa0b8", lineHeight: 1.7 }}>
                Use os filtros para ver <strong style={{ color: "#ddeeff" }}>jogos ao vivo</strong>, previsões de <strong style={{ color: "#ff7c2a" }}>🔥 mais gols</strong> ou <strong style={{ color: "#1e90ff" }}>🔒 menos gols</strong>.
                Passe o cursor nas previsões para ver <strong style={{ color: "#ddeeff" }}>explicação detalhada</strong>.
                O app <strong style={{ color: "#00e67a" }}>atualiza sozinho a cada 2 minutos</strong> com dados reais via IA.
              </div>
            </div>
            <button onClick={() => setDismiss(true)} style={{ background: "transparent", border: "none", color: "#536a82", fontSize: 18, cursor: "pointer", padding: 4, flexShrink: 0 }}>✕</button>
          </div>
        </div>
      )}

      {/* ── FILTROS ── */}
      <div style={{ position: "relative", zIndex: 5, maxWidth: 1120, margin: "18px auto 0", padding: "0 20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10, marginBottom: 12 }}>
          <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
            {FILTERS.map(f => {
              const cnt = games.filter(g => f.id === "all" || g.tags?.includes(f.id)).length;
              const on  = activeFilter === f.id;
              const bg  = { all: "#00e67a", live: "#ff3355", mais: "#ff7c2a", menos: "#1e90ff", top: "#ffcc00", enc: "#536a82" };
              return (
                <button key={f.id} onClick={() => setAF(f.id)} style={{
                  background: on ? bg[f.id] : "transparent",
                  border: `1px solid ${on ? "transparent" : "#1c2d3e"}`,
                  color: on ? (f.id === "top" || f.id === "all" ? "#000" : "#fff") : "#536a82",
                  padding: "6px 14px", borderRadius: 20,
                  fontFamily: "'DM Sans', sans-serif", fontSize: 12, fontWeight: 600,
                  cursor: "pointer", transition: "all .2s",
                  display: "flex", alignItems: "center", gap: 5,
                }}>
                  {f.icon} {f.label}
                  <span style={{ background: "rgba(0,0,0,.2)", padding: "1px 6px", borderRadius: 10, fontSize: 10 }}>{cnt}</span>
                </button>
              );
            })}
          </div>
          <span style={{ fontSize: 11, color: "#536a82" }}>Mostrando {filtered.length} jogo{filtered.length !== 1 ? "s" : ""}</span>
        </div>

        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {LEAGUES.map(l => {
            const on = activeLeague === l.id;
            return (
              <button key={l.id} onClick={() => setAL(l.id)} style={{
                background: on ? "rgba(28,45,62,.8)" : "transparent",
                border: `1px solid ${on ? "#243649" : "#1c2d3e"}`,
                color: on ? "#ddeeff" : "#536a82",
                padding: "5px 12px", borderRadius: 6,
                fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 600,
                cursor: "pointer", transition: "all .15s",
              }}>{l.flag} {l.label}</button>
            );
          })}
        </div>
      </div>

      {/* ── LEGENDA ── */}
      <div style={{ position: "relative", zIndex: 5, maxWidth: 1120, margin: "10px auto 0", padding: "0 20px" }}>
        <div style={{ background: "#0e1620", border: "1px solid #1c2d3e", borderRadius: 10, padding: "10px 16px", display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
          <span style={{ fontSize: 10, fontWeight: 700, color: "#536a82", letterSpacing: 2, textTransform: "uppercase" }}>Legenda</span>
          {[{ c: "#00b85e", l: "Vitória" }, { c: "#ffcc00", l: "Empate" }, { c: "#ff3355", l: "Derrota" }].map(({ c, l }) => (
            <div key={l} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12, color: "#8aa0b8" }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: c }} />{l}
            </div>
          ))}
          <span style={{ fontSize: 12, color: "#ff7c2a" }}>+X.5 = mais de X gols</span>
          <span style={{ fontSize: 12, color: "#1e90ff" }}>-X.5 = menos de X gols</span>
          <span style={{ fontSize: 12, color: "#536a82" }}>💡 Passe o cursor nas previsões!</span>
        </div>
      </div>

      {/* ── JOGOS ── */}
      <div style={{ position: "relative", zIndex: 5, maxWidth: 1120, margin: "14px auto 0", padding: "0 20px 60px" }}>
        {loading && (
          <div style={{ textAlign: "center", padding: "70px 20px" }}>
            <div style={{ fontSize: 44, animation: "spin .9s linear infinite", display: "inline-block", marginBottom: 16 }}>⚽</div>
            <div style={{ fontSize: 15, color: "#8aa0b8", marginBottom: 6 }}>Buscando jogos em tempo real...</div>
            <div style={{ fontSize: 12, color: "#536a82" }}>O GolMaster está consultando a web para obter dados de hoje</div>
          </div>
        )}

        {!loading && error && (
          <div style={{ textAlign: "center", padding: "50px 20px", background: "#0e1620", borderRadius: 16, border: "1px solid rgba(255,51,85,.2)" }}>
            <div style={{ fontSize: 32, marginBottom: 10 }}>⚠️</div>
            <div style={{ fontSize: 14, color: "#ff3355", marginBottom: 8 }}>Erro ao carregar os jogos</div>
            <div style={{ fontSize: 12, color: "#536a82", marginBottom: 20, maxWidth: 400, margin: "0 auto 20px" }}>{error}</div>
            <button onClick={load} style={{ background: "#00e67a", border: "none", color: "#000", padding: "10px 24px", borderRadius: 20, fontWeight: 700, cursor: "pointer", fontSize: 14 }}>
              ↻ Tentar Novamente
            </button>
          </div>
        )}

        {!loading && !error && filtered.length === 0 && (
          <div style={{ textAlign: "center", padding: "60px 20px", color: "#536a82" }}>
            <span style={{ fontSize: 32, display: "block", marginBottom: 12 }}>🔍</span>
            Nenhum jogo encontrado com este filtro.
          </div>
        )}

        {!loading && !error && filtered.length > 0 && (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {filtered.map((g, i) => <GameCard key={g.id || i} game={g} delay={i * 0.05} />)}
          </div>
        )}
      </div>

      {/* ── FOOTER ── */}
      <div style={{ position: "relative", zIndex: 5, textAlign: "center", padding: "0 20px 44px", fontSize: 11, color: "#536a82", lineHeight: 1.6, maxWidth: 560, margin: "0 auto" }}>
        ⚠️ Previsões geradas por IA com busca em tempo real. Não garantem resultados. Jogue com responsabilidade. Proibido para menores de 18 anos.
      </div>
    </div>
  );
}
